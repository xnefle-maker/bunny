// ALBERIA Main JavaScript

document.addEventListener('DOMContentLoaded', () => {
  initPetals();
  initExploreMode();
  initCreatorPanel();
  initMusic();
  initSlider();
  renderSections();
  initSearch();
  initGenresMenu();
  initPlatformTiles();
});

/* ===== Sakura Petals ===== */
function initPetals() {
  const container = document.getElementById('petals');
  if (!container) return;
  
  const count = 64;
  for (let i = 0; i < count; i++) {
    const petal = document.createElement('div');
    petal.className = 'petal';
    const size = 8 + Math.random() * 10;
    petal.style.width = size + 'px';
    petal.style.height = size + 'px';
    petal.style.left = Math.random() * 100 + 'vw';
    petal.style.animationDuration = (8 + Math.random() * 12) + 's';
    petal.style.animationDelay = (Math.random() * 15) + 's';
    petal.style.opacity = 0.3 + Math.random() * 0.4;
    container.appendChild(petal);
  }
}

/* ===== Creator Panel ===== */
function initCreatorPanel() {
  const btn = document.getElementById('creatorBtn');
  const panel = document.getElementById('creatorPanel');
  const overlay = document.getElementById('panelOverlay');
  const close = document.getElementById('panelClose');
  
  if (!btn || !panel) return;
  
  function openPanel() {
    panel.classList.add('open');
    overlay.classList.add('show');
  }
  
  function closePanel() {
    panel.classList.remove('open');
    overlay.classList.remove('show');
  }
  
  btn.addEventListener('click', openPanel);
  close.addEventListener('click', closePanel);
  overlay.addEventListener('click', closePanel);
}

/* ===== Music ===== */
let audio = null;
let isPlaying = false;

function initMusic() {
  const toggle = document.getElementById('musicToggle');
  const headerBtn = document.getElementById('musicBtn');
  
  // Soft ambient placeholder (user can replace with real file later)
  // For now we just toggle visual state since no audio file provided
  function toggleMusic() {
    isPlaying = !isPlaying;
    if (toggle) {
      toggle.classList.toggle('playing', isPlaying);
      toggle.textContent = isPlaying ? '♫' : '♪';
    }
    if (headerBtn) {
      headerBtn.textContent = isPlaying ? '♫' : '♪';
    }
    // Real audio would go here:
    // if (isPlaying) audio.play(); else audio.pause();
  }
  
  if (toggle) toggle.addEventListener('click', toggleMusic);
  if (headerBtn) headerBtn.addEventListener('click', toggleMusic);
}

/* ===== Explore gate + Featured continuous carousel ===== */
function initExploreMode() {
  const start = document.getElementById('exploreStart');
  const featured = document.getElementById('featured');
  if (!start || !featured) return;

  const unlockExplore = () => {
    if (document.body.classList.contains('explore-active')) return;
    document.body.classList.remove('explore-locked');
    document.body.classList.add('explore-active');
    start.setAttribute('aria-pressed', 'true');
    window.setTimeout(() => featured.scrollIntoView({ behavior: 'smooth', block: 'start' }), 180);
  };

  start.addEventListener('click', unlockExplore);
  // Keep the entry screen locked until the visitor explicitly starts exploring.
  const preventLockedScroll = (event) => {
    if (!document.body.classList.contains('explore-locked')) return;
    if (event.type === 'keydown' && !['ArrowDown','PageDown',' ','End'].includes(event.key)) return;
    event.preventDefault();
  };
  window.addEventListener('wheel', preventLockedScroll, { passive: false });
  window.addEventListener('touchmove', preventLockedScroll, { passive: false });
  window.addEventListener('keydown', preventLockedScroll, { passive: false });
  const stopReturningAboveFeatured = (event) => {
    if (!document.body.classList.contains('explore-active')) return;
    const boundary = featured.getBoundingClientRect().top + window.scrollY;
    if (window.scrollY <= boundary + 3 && ((event.type === 'wheel' && event.deltaY < 0) || (event.type === 'touchstart'))) {
      if (event.type === 'wheel') event.preventDefault();
      document.body.classList.add('featured-boundary-locked');
    } else if (window.scrollY > boundary + 12) {
      document.body.classList.remove('featured-boundary-locked');
    }
  };
  window.addEventListener('wheel', stopReturningAboveFeatured, { passive:false });
  window.addEventListener('scroll', () => {
    if (document.body.classList.contains('explore-active')) {
      const boundary = featured.getBoundingClientRect().top + window.scrollY;
      if (window.scrollY > boundary + 12) document.body.classList.remove('featured-boundary-locked');
    }
  }, {passive:true});
  window.addEventListener('keydown', (event) => {
    if (document.body.classList.contains('explore-active') && ['ArrowUp','Home'].includes(event.key)) {
      const boundary = featured.getBoundingClientRect().top + window.scrollY;
      if (window.scrollY <= boundary + 3) event.preventDefault();
    }
  }, {passive:false});
}

let carouselDirection = 1;
let carouselPauseTimer = null;

function initSlider() {
  const track = document.getElementById('sliderTrack');
  const viewport = document.getElementById('sliderViewport');
  if (!track || typeof ALL_GAMES === 'undefined') return;

  const featured = ALL_GAMES.filter(game => !game.upcoming).slice(0, 30);
  if (!featured.length) return;

  const makeItems = (items, copy = false) => items.map(game => `
    <a class="featured-game" href="game.html?id=${encodeURIComponent(game.id)}" ${copy ? 'tabindex="-1" aria-hidden="true"' : ''}>
      <span class="featured-game-art"><img src="${game.cover}" alt="${game.titleFa || game.title}" loading="lazy"></span>
      <span class="featured-game-title">${game.titleFa || game.title}</span>
      <span class="featured-game-year">${game.year}</span>
    </a>
  `).join('');

  // Two identical sets make the automatic horizontal loop seamless.
  track.innerHTML = makeItems(featured) + makeItems(featured, true);

  const pauseTemporarily = (direction) => {
    carouselDirection = direction;
    track.style.animationDirection = direction > 0 ? 'normal' : 'reverse';
    track.classList.add('is-paused');
    window.clearTimeout(carouselPauseTimer);
    carouselPauseTimer = window.setTimeout(() => track.classList.remove('is-paused'), 900);
  };

  document.getElementById('sliderPrev')?.addEventListener('click', () => pauseTemporarily(-1));
  document.getElementById('sliderNext')?.addEventListener('click', () => pauseTemporarily(1));
  viewport?.addEventListener('mouseenter', () => track.classList.add('is-paused'));
  viewport?.addEventListener('mouseleave', () => track.classList.remove('is-paused'));
  viewport?.addEventListener('focusin', () => track.classList.add('is-paused'));
  viewport?.addEventListener('focusout', () => track.classList.remove('is-paused'));
  viewport?.addEventListener('touchstart', () => track.classList.add('is-paused'), { passive: true });
  viewport?.addEventListener('touchend', () => track.classList.remove('is-paused'), { passive: true });
}

/* ===== Render Game Cards ===== */
function createCard(game) {
  return `
    <a href="game.html?id=${game.id}" class="game-card">
      <img src="${game.cover}" alt="${game.title}" loading="lazy" 
           onerror="this.src='https://via.placeholder.com/300x450/2c1c28/f4a7b9?text=${encodeURIComponent(game.title)}'">
      <div class="card-overlay">
        <div class="card-title">${game.titleFa || game.title}</div>
      </div>
    </a>
  `;
}

function renderSections() {
  if (typeof ALL_GAMES === 'undefined') return;
  
  const popular = ALL_GAMES.filter(g => g.popular).slice(0, 8);
  const newest = [...ALL_GAMES].filter(g => !g.upcoming).sort((a, b) => b.year - a.year).slice(0, 8);
  const upcoming = ALL_GAMES.filter(g => g.upcoming);
  
  const popularGrid = document.getElementById('popularGrid');
  const newGrid = document.getElementById('newGrid');
  const upcomingGrid = document.getElementById('upcomingGrid');
  const genresGrid = document.getElementById('genresGrid');
  
  if (popularGrid) popularGrid.innerHTML = popular.map(createCard).join('');
  if (newGrid) newGrid.innerHTML = newest.map(createCard).join('');
  if (upcomingGrid) upcomingGrid.innerHTML = (upcoming.length ? upcoming : popular.slice(0, 4)).map(createCard).join('');
  
  if (genresGrid && typeof GENRES !== 'undefined') {
    genresGrid.innerHTML = GENRES.map((g, i) => {
      const sample = ALL_GAMES.find(game => (game.genres || []).some(x => x.toLowerCase().includes(g.id) || x.includes(g.name))) || ALL_GAMES[i % ALL_GAMES.length];
      return `<a href="archive.html?genre=${encodeURIComponent(g.id)}" class="genre-card" style="background-image:url('${sample.cover}')">
        <span class="genre-icon">${g.icon}</span><span class="genre-name">${g.name}</span>
      </a>`;
    }).join('');
  }
}

/* ===== Header genre menu ===== */
function initGenresMenu() {
  const toggle = document.getElementById('genresMenuToggle');
  const menu = document.getElementById('genresMenu');
  if (!toggle || !menu || typeof GENRES === 'undefined') return;

  menu.innerHTML = GENRES.map(genre =>
    `<a class="genre-menu-item" href="archive.html?genre=${encodeURIComponent(genre.id)}"><span>${genre.icon}</span>${genre.name}</a>`
  ).join('');

  const closeMenu = () => {
    menu.classList.remove('open');
    toggle.setAttribute('aria-expanded', 'false');
  };
  toggle.addEventListener('click', (event) => {
    event.stopPropagation();
    const isOpen = menu.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(isOpen));
  });
  document.addEventListener('click', (event) => {
    if (!menu.contains(event.target) && !toggle.contains(event.target)) closeMenu();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeMenu();
  });
}

/* ===== Global game search ===== */
function initSearch() {
  const input = document.getElementById('globalSearch');
  const suggestions = document.getElementById('searchSuggestions');
  if (!input) return;

  const goToArchive = () => {
    const q = input.value.trim();
    if (q) window.location.href = `archive.html?search=${encodeURIComponent(q)}`;
  };
  const closeSuggestions = () => {
    if (suggestions) suggestions.classList.remove('open');
  };
  const showSuggestions = () => {
    if (!suggestions || typeof ALL_GAMES === 'undefined') return;
    const q = input.value.trim().toLocaleLowerCase();
    if (!q) { closeSuggestions(); suggestions.innerHTML = ''; return; }
    const matches = ALL_GAMES.filter(game =>
      (game.title || '').toLocaleLowerCase().includes(q) ||
      (game.titleFa || '').toLocaleLowerCase().includes(q) ||
      (game.characters || []).some(name => name.toLocaleLowerCase().includes(q))
    ).slice(0, 6);
    suggestions.innerHTML = matches.length
      ? matches.map(game => `<a class="search-suggestion" role="option" href="game.html?id=${encodeURIComponent(game.id)}"><img src="${game.cover}" alt="" loading="lazy"><span><strong>${game.titleFa || game.title}</strong><small>${game.title}</small></span></a>`).join('') + `<a class="search-all-results" href="archive.html?search=${encodeURIComponent(input.value.trim())}">نمایش همه نتایج جستجو</a>`
      : `<div class="search-no-match">بازی‌ای پیدا نشد؛ برای جستجوی کامل Enter بزنید.</div>`;
    suggestions.classList.add('open');
  };

  input.addEventListener('input', showSuggestions);
  input.addEventListener('focus', showSuggestions);
  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') { event.preventDefault(); goToArchive(); }
    if (event.key === 'Escape') closeSuggestions();
  });
  document.addEventListener('click', (event) => {
    if (!event.target.closest('.search-box')) closeSuggestions();
  });
}


function initPlatformTiles() {
  const buttons = [...document.querySelectorAll('.platform-tile')];
  const grid = document.getElementById('platformGrid');
  if (!buttons.length || !grid) return;
  const show = (platform) => {
    buttons.forEach(b => b.classList.toggle('active', b.dataset.platform === platform));
    const list = ALL_GAMES.filter(g => (g.platforms || []).includes(platform)).slice(0, 10);
    grid.innerHTML = list.map(createCard).join('');
  };
  buttons.forEach(b => b.addEventListener('click', () => show(b.dataset.platform)));
  show('PS5');
  const genreRail = document.getElementById('genresGrid');
  if (genreRail) { let direction = 1; let timer = window.setInterval(() => { if (genreRail.matches(':hover')) return; const end = genreRail.scrollWidth - genreRail.clientWidth; if (end <= 0) return; genreRail.scrollLeft += direction * 1; if (genreRail.scrollLeft >= end - 2) direction = -1; if (genreRail.scrollLeft <= 2) direction = 1; }, 28); window.addEventListener('beforeunload', () => clearInterval(timer)); }
}
